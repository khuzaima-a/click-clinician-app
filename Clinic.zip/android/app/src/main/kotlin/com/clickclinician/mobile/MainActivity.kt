package com.clickclinicians.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
